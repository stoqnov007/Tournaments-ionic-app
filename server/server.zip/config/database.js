// module.exports = {
//     'url': 'mongodb://localhost:27017/users'
// }

module.exports = {
    'url': 'mongodb://StefanDev:parola123@ds018848.mlab.com:18848/tournamentsusers'
}